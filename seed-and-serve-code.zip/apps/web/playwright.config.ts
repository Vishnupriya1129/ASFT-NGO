import { defineConfig, devices } from '@playwright/test';

export default defineConfig({
  testDir: './tests/e2e',
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 2 : 0,
  workers: process.env.CI ? 1 : undefined,
  reporter: [
    ['html', { outputFolder: 'playwright-report' }],
    ['list'],
  ],
  use: {
    baseURL:     process.env.PLAYWRIGHT_BASE_URL ?? 'http://localhost:3000',
    trace:       'on-first-retry',
    screenshot:  'only-on-failure',
    video:       'on-first-retry',
  },
  projects: [
    { name: 'chromium',       use: { ...devices['Desktop Chrome'] } },
    { name: 'Mobile Safari',  use: { ...devices['iPhone 13'] } },
  ],
  webServer: {
    command: 'pnpm dev',
    url:     'https://seed-and-serve-4djp3dt4c-vishnus-projects-76247019.vercel.app',
    reuseExistingServer: !process.env.CI,
    timeout: 120 * 1000,
  },
});