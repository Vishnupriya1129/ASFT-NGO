import { redirect } from 'next/navigation';

export default function GalleryPage() {
  redirect('/programs');
}